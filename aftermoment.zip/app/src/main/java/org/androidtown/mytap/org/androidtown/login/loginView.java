package org.androidtown.mytap.org.androidtown.login;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.loopj.android.http.*;

import org.androidtown.mytap.R;


public class loginView extends ActionBarActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("start","start");

        Button login_btn = (Button)findViewById(R.id.login);
        login_btn.setOnClickListener(this);
        AsyncHttpClient client = HttpClient.getInstance();
        PersistentCookieStore myCookieStore = new PersistentCookieStore(this);
        client.setCookieStore(myCookieStore);
    }


    @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.main, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        RequestParams params = new RequestParams();
        EditText id = (EditText)findViewById(R.id.login_id);
        EditText pwd = (EditText)findViewById(R.id.login_pwd);
        Log.i("Msg","Clicked Login Btn id : "+id.getText()+" pwd : "+pwd.getText());
        params.put("id", id.getText().toString());
        params.put("pwd", pwd.getText().toString());
        HttpClient.get("", params, new AsyncHttpResponseHandler() {
            public void onSuccess(String response) {
                System.out.println(response);
                TextView status = (TextView) findViewById(R.id.login_stauts);
                status.setText(response.toString());
            }
        });

    }
}

